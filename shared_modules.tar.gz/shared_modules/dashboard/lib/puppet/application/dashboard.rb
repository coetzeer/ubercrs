require 'puppet/face'
require 'puppet/application/face_base'

class Puppet::Application::Dashboard < Puppet::Application::FaceBase
end
